package com.code.entity;

public enum Role {
    ADMIN,
    CUSTOMER
}
